from fairchem.core.datasets import AseDBDataset
import numpy as np
import pickle
import lmdb
import multiprocessing as mp
import os

d_and_f_block_elements = {
    # d-block (transition metals)
    'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
    'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd',
    'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg',
    'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds', 'Rg', 'Cn',
    
    # f-block (lanthanides)
    'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb',
    'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu',
    
    # f-block (actinides)
    'Ac', 'Th', 'Pa', 'U', 'Np', 'Pu', 'Am', 'Cm', 'Bk',
    'Cf', 'Es', 'Fm', 'Md', 'No', 'Lr'
}

main_group_elements = {
    'Li', 'Be',
    'B', 
    'Na', 'Mg',
    'Al',
    'K', 'Ca',
    'Ga', 'Ge', 'As', 'Se',
    'Rb', 'Sr',
    'In', 'Sn', 'Sb', 'Te',
    'Cs', 'Ba',
    'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn',
    'Fr', 'Ra',
    'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og'
}

dataset_path = "./val"
dataset = AseDBDataset({"src": dataset_path})
MOL_IDS = [val for inner in dataset.db_ids for val in inner]

db_names = {0: "all_data.lmdb", 1: "all_data_No_H.lmdb", 2: "larger_than_5.lmdb", 3: "d_f_block.lmdb", 4: "spicy_main_group.lmdb", 5: "main_and_d.lmdb"}
map_sizing_GB = {0: 25, 1: 25, 2: 25, 3: 25, 4: 25, 5: 25}
BYTES_TO_GB = 1024 * 1024 * 1024
BATCH_SIZE = 25_000

def split_list(lst, n):
    k, m = divmod(len(lst), n)
    return [lst[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(n)]


def writer(db_id, queue, db_dir):
    db_path = os.path.join(db_dir, db_names[db_id])
    env = lmdb.open(db_path, subdir=False, lock=False, map_size=25*BYTES_TO_GB)
    key = 0
    buffer = []
    while True:
        item = queue.get()
        if item is None:
            break
        value = item
        buffer.append(value)

        if len(buffer) >= BATCH_SIZE:
            with env.begin(write=True) as txn:
                for value in buffer:
                    txn.put(f"{key}".encode('ascii'), value)
                    key += 1
        
                    if key % 50_000 == 0:
                        print(f"Writer {db_id} has written {key} entries")
            buffer.clear()
    
    if len(buffer) != 0:
        for value in buffer:
            with env.begin(write=True) as txn:
                txn.put(f"{key}".encode('ascii'), value)
                key += 1
    env.close()


def router(main_queue, dq_queues):
    while True:
        item = main_queue.get()
        if item is None:
            break
        db_id, value = item
        dq_queues[db_id].put(value)

    # Signal each writer to stop
    for q in db_queues.values():
        q.put(None)

def worker(main_queue, chunk, worker_id):
    print(f"Opening {worker_id=}")
    for i ,mol_id in enumerate(chunk):
        atoms = dataset.get_atoms(mol_id)
        syms = atoms.get_chemical_symbols()
        
        to_route = {'atoms': syms, "coordinates": [np.array(atoms.get_positions(), dtype=np.float32)], 'smi': "C", 'OMol_id': mol_id}
        to_route = pickle.dumps(to_route)

        no_H = [sym for sym in syms if sym != "H"]
        has_d_block = any(sym in d_and_f_block_elements for sym in syms)
        has_main_group = any(sym in main_group_elements for sym in syms)
        
        main_queue.put((0, to_route))
        if len(no_H) != 0:
            main_queue.put((1, to_route))
        if len(syms) > 4 and len(no_H) >= 3:
            main_queue.put((2, to_route))
        if has_d_block:
            main_queue.put((3, to_route))
        if has_main_group:
            main_queue.put((4, to_route))
        if has_d_block or has_main_group:
            main_queue.put((5, to_route))

        if i % 100_000 == 0:
            print(f"Worker {worker_id} has finished {i}/{len(chunk)}")
    print(f"Worker: {worker_id=} has finished")

if __name__ == "__main__":
    db_count = 6
    db_dir = "./lmdbs"
    os.makedirs(db_dir, exist_ok=True)

    # make the queues
    main_queue = mp.Queue()
    db_queues = {i: mp.Queue() for i in range(db_count)}

    # start writers
    writers = []
    for db_id in range(db_count):
        p = mp.Process(target=writer, args=(db_id, db_queues[db_id], db_dir))
        p.start()
        writers.append(p)

    # routing
    router_process = mp.Process(target=router, args=(main_queue, db_queues))
    router_process.start()

    # start workers
    num_workers = 10
    mol_id_chunks = split_list(MOL_IDS, num_workers)
    workers = []
    for i in range(num_workers):
        p = mp.Process(target=worker, args=(main_queue, mol_id_chunks[i], i))
        p.start()
        workers.append(p)

    for w in workers:
        w.join()

    main_queue.put(None)
    router_process.join()

    for w in writers:
        w.join()