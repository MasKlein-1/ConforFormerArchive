from multiprocessing import Pool, cpu_count, current_process
from collections import defaultdict
import numpy as np
import pickle

from fairchem.core.datasets import AseDBDataset

dataset_path = "./neutral_val"
dataset = AseDBDataset({"src": dataset_path})
MOL_IDS = [val for inner in dataset.db_ids for val in inner]

def process_mids(args):
    mol_ids, idx = args
    
    local_non_pbc = []
    local_formulas = {}
    local_atoms_count = defaultdict(int)
    local_seq_len = defaultdict(int)
    local_seq_len_no_H = defaultdict(int)

    for mol_id in mol_ids:
        atoms = dataset.get_atoms(mol_id)
        if np.allclose(atoms.pbc, [False, False, False]):
            local_non_pbc.append(mol_id)

            symbols = atoms.get_chemical_symbols()
            for sym in symbols:
                local_atoms_count[sym] += 1
            
            formula = atoms.get_chemical_formula()
            if formula not in local_formulas:
                local_formulas[formula] = []
            local_formulas[formula].append(mol_id)

            local_seq_len[len(symbols)] += 1
            local_seq_len_no_H[int(np.sum(np.array(symbols) != "H"))] += 1
        else:
            print(mol_id)
        
    return local_non_pbc, local_formulas, local_atoms_count, local_seq_len, local_seq_len_no_H


def merge_dict_list(dict_list):
    merged = {}
    for formula_dict in dict_list:
        for form, mids in formula_dict.items():
            if form not in merged:
                merged[form] = []
            for mid in mids:
                merged[form].append(mid)
    return merged

def merge_counts(dict_int):
    merged = defaultdict(int)
    for count_dict in dict_int:
        for atom, count in count_dict.items():
            merged[atom] += count
    return merged

def merge_list_int(list_int):
    merged = []
    for inner_list in list_int:
        for val in inner_list:
            merged.append(val)
    return merged


if __name__ == "__main__":
    n_proc = cpu_count()
    chunks = np.array_split(range(len(dataset)), n_proc)

    inputs = [(chunk, idx) for idx, chunk in enumerate(chunks)]

    with Pool(processes=n_proc) as pool:
        results = pool.map(process_mids, inputs)

    non_pbc = [inner_list[0] for inner_list in results]
    formulas = [inner_list[1] for inner_list in results]
    atoms_count = [inner_list[2] for inner_list in results]
    seq_len = [inner_list[3] for inner_list in results]
    seq_len_no_H = [inner_list[4] for inner_list in results]


    non_pbc_merged = merge_list_int(non_pbc)
    np.save("all_non_pbc.omol", non_pbc_merged)

    formulas_merged = merge_dict_list(formulas)
    with open("formulas.pkl", "wb") as f:
        pickle.dump(formulas_merged, f)
    
    atoms_count_merged = merge_counts(atoms_count)
    with open("atom_counts.pkl", "wb") as f:
        pickle.dump(atoms_count_merged, f)
    
    seq_len_merged = merge_counts(seq_len)
    with open("seq_len.pkl", "wb") as f:
        pickle.dump(seq_len_merged, f)
    
    seq_len_no_H_merged = merge_counts(seq_len_no_H)
    with open("seq_len_no_H.pkl", "wb") as f:
        pickle.dump(seq_len_no_H_merged, f)