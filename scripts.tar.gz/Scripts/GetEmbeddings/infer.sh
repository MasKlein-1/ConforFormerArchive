#bin/bash

# directories
unimol_dir=./unimol
data_path=../UniMolDatasetSplit
data_subset=isomers
dict_name=dict_unimol.txt

task_name=embed
results_path=results
weight_path=./Seed3.pt
loss_func="encoder_embed"
task_num=2 # 2 for bace, 128 for pcba, 12 for tox21
only_polar=0

if [ "$task_name" == "qm7dft" ] || [ "$task_name" == "qm8dft" ] || [ "$task_name" == "qm9dft" ]; then
        metric="valid_agg_mae"
elif [ "$task_name" == "esol" ] || [ "$task_name" == "freesolv" ] || [ "$task_name" == "lipo" ]; then
    metric="valid_agg_rmse"
else
    metric="valid_agg_auc"
fi


python all_infer.py --user-dir $unimol_dir $data_path --valid-subset isomers --task-name $task_name \
       --path $weight_path --results-path $results_path --dict-name=$dict_name \
       --num-workers 8 --ddp-backend=c10d --batch-size 10 \
       --arch unimol_base --task get_embed_ft --loss $loss_func \
       --fp16 --fp16-init-scale 4 --fp16-scale-window 256 \
       --classification-head-name $task_name --num-classes $task_num \
       --only-polar $only_polar --mode "infer" --use-shuffle=False
