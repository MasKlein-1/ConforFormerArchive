#!/usr/bin/env python3 -u
# Copyright (c) DP Techonology, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import logging
import os
import sys
import pickle
import torch
from unicore import checkpoint_utils, distributed_utils, options, utils
from unicore.logging import progress_bar
from unicore import tasks
import torch.multiprocessing as mp
import torch.nn.functional as F

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=os.environ.get("LOGLEVEL", "INFO").upper(),
    stream=sys.stdout,
)
logger = logging.getLogger("unimol.inference")


def main(args):

    assert (
        args.batch_size is not None
    ), "Must specify batch size either with --batch-size"

    use_fp16 = args.fp16
    use_cuda = torch.cuda.is_available() and not args.cpu

    if use_cuda:
        torch.cuda.set_device(args.device_id)

    if args.distributed_world_size > 1:
        data_parallel_world_size = distributed_utils.get_data_parallel_world_size()
        data_parallel_rank = distributed_utils.get_data_parallel_rank()
    else:
        data_parallel_world_size = 1
        data_parallel_rank = 0

    # Load model
    logger.info("loading model(s) from {}".format(args.path))
    state = checkpoint_utils.load_checkpoint_to_cpu(args.path)
    task = tasks.setup_task(args)
    model = task.build_model(args)
    model.load_state_dict(state["model"], strict=False)

    # Move models to GPU
    if use_cuda:
        model.cuda()
        # fp16 only supported on CUDA for fused kernels
        if use_fp16:
            model.half()

    # Print args
    logger.info(args)

    # Build loss
    loss = task.build_loss(args)
    loss.eval()

    for subset in args.valid_subset.split(","):
        try:
            task.load_dataset(subset, combine=False, epoch=1)
            dataset = task.dataset(subset)
        except KeyError:
            raise Exception("Cannot find dataset: " + subset)

        if not os.path.exists(args.results_path):
            os.makedirs(args.results_path)
        try:
            fname = (args.path).split("/")[-2]
        except:
            fname = 'infer'
        save_path = os.path.join(args.results_path, fname + "_" + subset + ".out.pkl")
        # Initialize data iterator
        # itr = task.get_batch_iterator(
        #     dataset=dataset,
        #     batch_size=args.batch_size,
        #     ignore_invalid_inputs=True,
        #     required_batch_size_multiple=args.required_batch_size_multiple,
        #     seed=args.seed,
        #     num_shards=data_parallel_world_size,
        #     shard_id=data_parallel_rank,
        #     num_workers=args.num_workers,
        #     data_buffer_size=args.data_buffer_size,
        # ).next_epoch_itr(shuffle=False)
        progress = progress_bar.progress_bar(
            range(len(dataset)),
            log_format=args.log_format,
            log_interval=args.log_interval,
            prefix=f"valid on '{subset}' subset",
            default_log_format=("tqdm" if not args.no_progress_bar else "simple"),
        )
        num_batches = 0
        log_outputs = []
        src_tokens_batch = []
        src_distance_batch = []
        src_coord_batch = []
        src_edge_type_batch = []
        model.eval()
        for i, sample in enumerate(progress):
            sample = dataset[i]
            # print(sample.keys())
            sample = utils.move_to_cuda(sample) if use_cuda else sample
            if len(sample) == 0:
                continue
            
            src_tokens_batch.append(sample["net_input.src_tokens"])
            src_distance_batch.append(sample["net_input.src_distance"])
            src_coord_batch.append(sample["net_input.src_coord"])
            src_edge_type_batch.append(sample["net_input.src_edge_type"])
            progress.log({}, step=i)
            
            if len(src_coord_batch) % args.batch_size == 0:
                src_tokens = torch.stack(src_tokens_batch, dim=0)
                src_tokens_batch.clear()
                
                src_distance = torch.stack(src_distance_batch, dim=0)
                src_distance_batch.clear()
                
                src_coord = torch.stack(src_coord_batch, dim=0)
                src_coord_batch.clear()
                
                src_edge_type = torch.stack(src_edge_type_batch, dim=0)
                src_edge_type_batch.clear()

                with torch.no_grad():
                    net_output = model(
                        src_tokens= src_tokens,
                        src_distance= src_distance,
                        src_coord= src_coord,
                        src_edge_type=src_edge_type,
                        features_only=True,
                        classification_head_name=args.classification_head_name,
                    )

                logit_output = net_output[2]

                reg_output = net_output[0]
                sample_size = reg_output.shape[0]
                log_output = {
                    # "embedding": reg_output,
                    "cls_token": reg_output[:, 0, :],
                    "smi_name": sample["smi_name"],
                    "target": sample["target.finetune_target"],
                    "logits": logit_output,
                    "sample_size": sample_size,
                    "bsz": len(src_tokens_batch),
                    "atoms": sample["atoms"],
                    }            
                log_outputs.append(log_output)
                num_batches += 1
                # _, _, log_output = task.valid_step(sample, model, loss, test=True)
            if num_batches == 1_000:
                num_batches = 0
                print("save")
                save_path = os.path.join(args.results_path, fname + "_" + subset + f"_{args.task_name}" + f"_Seed3base{i}" + ".out.pkl")
                pickle.dump(log_outputs, open(save_path, "wb"))
                
                log_outputs.clear()
                torch.cuda.empty_cache()
            
            # if i == 100_000:
            #     break

        if len(log_outputs) != 0:
            save_path = os.path.join(args.results_path, fname + "_" + subset + f"_{args.task_name}" + f"_Seed3base_{i}" + ".out.pkl")
            pickle.dump(log_outputs, open(save_path, "wb"))
        logger.info("Done inference! ")
    return None


def cli_main():
    parser = options.get_validation_parser()
    options.add_model_args(parser)
    args = options.parse_args_and_arch(parser)

    distributed_utils.call_main(args, main)


if __name__ == "__main__":
    cli_main()
