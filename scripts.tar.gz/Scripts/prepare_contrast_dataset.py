import lmdb
import pickle
from collections import defaultdict
from multiprocessing import Pool, cpu_count
from tqdm import tqdm

LMDB_PATH = "train.lmdb"


def chunk_list(lst, n):
    """Split lst into n roughly equal chunks."""
    k, m = divmod(len(lst), n)
    return [lst[i*k + min(i, m):(i+1)*k + min(i+1, m)] for i in range(n)]


def init_lmdb_env(lmdb_path):
    env = lmdb.open(
        lmdb_path,
        subdir=False,
        readonly=True,
        lock=False,
        readahead=False,
        meminit=False,
        max_readers=256,
    )
    return env


def stringify_molecular_formula(dp: dict):
    atoms = dp['atoms']
    atoms = [a for a in atoms]
    sorted_atoms = sorted(atoms)
    return "".join(sorted_atoms)


def process_keys(key_chunk):
    env = init_lmdb_env(LMDB_PATH)
    isomer_dict = defaultdict(list)
    with env.begin() as txn:
        for key in key_chunk:
            dp = pickle.loads(txn.get(key))
            atoms_string = stringify_molecular_formula(dp)
            isomer_dict[atoms_string].append(key)
    return isomer_dict


def merge_dicts(results):
    output = defaultdict(list)
    for dictionary in results:
        for key, values in dictionary.items():
            for val in values:
                output[key].append(val)
    return output


def main():
    print("starting")
    env = init_lmdb_env(LMDB_PATH)
    with env.begin() as txn:
        keys = list(txn.cursor().iternext(values=False))
    print("Keys read")

    n_proc = cpu_count()
    key_chunks = chunk_list(keys, n_proc**2)

    with Pool(processes=n_proc) as pool:
        results = []
        for result in tqdm(pool.imap_unordered(process_keys, key_chunks), total=len(key_chunks), desc="Processing"):
            results.append(result)

    merged_isomers = merge_dicts(results)
    with open("all_isomers_key_no_H.pkl", "wb") as f:
        pickle.dump(merged_isomers, f)

if __name__ == "__main__":
    main()