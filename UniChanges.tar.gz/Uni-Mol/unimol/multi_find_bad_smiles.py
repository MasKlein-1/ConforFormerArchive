from multiprocessing import Pool, cpu_count
from itertools import islice
import os
import lmdb
import pickle
from rdkit import Chem
import pandas as pd

OUTPUT_DIR = "."
FINAL_OUTPUT = "merged.csv"
LMDB_PATH = "example_data/molecule"

def init_lmdb_env(lmdb_path):
    env = lmdb.open(
        lmdb_path,
        subdir=False,
        readonly=True,
        lock=False,
        readahead=False,
        meminit=False,
        max_readers=256,
    )
    return env

def round_robin_chunks(keys, n_processes):
    """
    Returns n_processes iterators that yield items in round-robin fashion.
    Suitable for large iterables.
    """
    keys = iter(keys)
    return [islice(keys, i, None, n_processes) for i in range(n_processes)]


def merge_output_files(n_workers):
    with open(FINAL_OUTPUT, 'w') as fout:
        for i in range(n_workers):
            part_file = os.path.join(OUTPUT_DIR, f"test_{i}")
            with open(part_file, 'r') as fin:
                fout.writelines(fin.readlines())
                


def process_keys(process_id, keys_chunk):
    """
    Process a chunk of keys and write results to a unique file.
    """
    env = init_lmdb_env(os.path.join(LMDB_PATH, "train.lmdb"))
    txn = env.begin()
    
    output_path = os.path.join(OUTPUT_DIR, f"test_{process_id}")
    bad_smi = {
        "idx": [],
        "smi": [],
        "num_conf": [],
    }
    with open(output_path, 'w') as f:
        f.write("idx, smi, num_conf, can_RD\n")
        for key in keys_chunk:
            dp_pickled = txn.get(key)
            dp = pickle.loads(dp_pickled)

            smi = dp["smi"]
            num_conf = len(dp["coordinates"])
            can_RD = True if Chem.MolFromSmiles(smi) is not None else False
            f.write(f"{key}, {smi}, {num_conf}, {can_RD},\n")

            if not can_RD:
                bad_smi["smi"].append(smi)
                bad_smi["num_conf"].append(num_conf)
                bad_smi["idx"].append(key)
    return bad_smi


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    env = init_lmdb_env(os.path.join(LMDB_PATH, "train.lmdb"))
    txn = env.begin()
    keys = list(txn.cursor().iternext(values=False))

    n_workers = cpu_count()
    chunks = round_robin_chunks(keys, n_workers)
    tasks = [(i, chunk) for i, chunk in enumerate(chunks)]

    with Pool(n_workers) as pool:
        results = pool.starmap(process_keys, tasks)

    merge_output_files(n_workers)
    print(f"Merged output written to {FINAL_OUTPUT}")

    final_dict = {}
    for d in results:
        final_dict.update(d)
    pd.DataFrame(final_dict).to_csv(os.path.join(OUTPUT_DIR, "BadSmiles.csv"))

if __name__ == "__main__":
    main()