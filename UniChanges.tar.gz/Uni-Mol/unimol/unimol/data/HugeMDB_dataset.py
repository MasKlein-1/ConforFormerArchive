import os
import numpy as np
from functools import lru_cache
import logging

import ctypes
import sys
import json

logger = logging.getLogger(__name__)

ATOMIC_NUMBER_TO_SYMBOL = {
    1: "H", 2: "He", 3: "Li", 4: "Be", 5: "B",
    6: "C", 7: "N", 8: "O", 9: "F", 10: "Ne",
    11: "Na", 12: "Mg", 13: "Al", 14: "Si", 15: "P",
    16: "S", 17: "Cl", 18: "Ar", 19: "K", 20: "Ca",
    21: "Sc", 22: "Ti", 23: "V", 24: "Cr", 25: "Mn",
    26: "Fe", 27: "Co", 28: "Ni", 29: "Cu", 30: "Zn",
    31: "Ga", 32: "Ge", 33: "As", 34: "Se", 35: "Br",
    36: "Kr", 37: "Rb", 38: "Sr", 39: "Y", 40: "Zr",
    41: "Nb", 42: "Mo", 43: "Tc", 44: "Ru", 45: "Rh",
    46: "Pd", 47: "Ag", 48: "Cd", 49: "In", 50: "Sn",
    51: "Sb", 52: "Te", 53: "I", 54: "Xe", 55: "Cs",
    56: "Ba", 57: "La", 58: "Ce", 59: "Pr", 60: "Nd",
    61: "Pm", 62: "Sm", 63: "Eu", 64: "Gd", 65: "Tb",
    66: "Dy", 67: "Ho", 68: "Er", 69: "Tm", 70: "Yb",
    71: "Lu", 72: "Hf", 73: "Ta", 74: "W", 75: "Re",
    76: "Os", 77: "Ir", 78: "Pt", 79: "Au", 80: "Hg",
    81: "Tl", 82: "Pb", 83: "Bi", 84: "Po", 85: "At",
    86: "Rn", 87: "Fr", 88: "Ra", 89: "Ac", 90: "Th",
    91: "Pa", 92: "U", 93: "Np", 94: "Pu", 95: "Am",
    96: "Cm", 97: "Bk", 98: "Cf", 99: "Es", 100: "Fm",
    101: "Md", 102: "No", 103: "Lr", 104: "Rf", 105: "Db",
    106: "Sg", 107: "Bh", 108: "Hs", 109: "Mt", 110: "Ds",
    111: "Rg", 112: "Cn", 113: "Nh", 114: "Fl", 115: "Mc",
    116: "Lv", 117: "Ts", 118: "Og"
}


class HMDBDataset:
    def __init__(self, db_path, so_path):
        if not os.path.exists(so_path):
            print(f"Error: Dynamic library '{so_path}' not found.")
            sys.exit(1)       
        self.so_path = so_path
        self._keys = np.load(db_path) # Assumption that the MIDs are loaded in a numpy binary

    def connect_db(self, so_path, save_to_self=False):
        """
        Function to initialize HugeMDB if that is not already done on a given thread
        """
        try:
            # Load the dynamic library
            # In Linux, CDLL is usually sufficient. WinDLL might be needed for Windows.
            HugeMDB = ctypes.CDLL(so_path)

        except OSError as e:
            print(f"Error: Could not load library '{so_path}'. Ensure it is in the same directory as the script or in the system path.")
            print(f"Details: {e}")
            sys.exit(1) # Exit with an error

        try:
            # Define function signature for HugeMDB_Ini
            HugeMDB.HugeMDB_Ini.argtypes = None # Does not take arguments
            HugeMDB.HugeMDB_Ini.restype = ctypes.c_int # Returns int

        except AttributeError:
            print(f"Error: Function 'HugeMDB_Ini' not found in the library.")
            sys.exit(1)

        try:
            # Define function signature
            HugeMDB.HugeMDB_GetMID.argtypes = [
                ctypes.c_uint,              # molecule graph ID in our database (this ID changes after database rebuild)
                ctypes.POINTER(ctypes.c_char) # string variable with JSON structure containing molecule graph description and coordinates of all its isomers
            ]
            HugeMDB.HugeMDB_GetMID.restype = None
            # HugeMDB.func.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_char)]

        except AttributeError:
            print(f"Error: Function 'HugeMDB_GetMID' not found")
            sys.exit(1)

        init_result = HugeMDB.HugeMDB_Ini()
        print(f"HugeMDB_Ini result: {init_result}")
        if init_result < 0 : sys.exit(1)

        if not save_to_self:
            return HugeMDB
        else:
            self.hmdb = HugeMDB

    def __len__(self):
        return len(self._keys)
    
    @staticmethod
    def parse_hmdb_result(result_str: str):
        """
        Parses the HugeMDB search output into the correct format for the model training.

        Args:
          result_str (str): the raw utf-8 parsed string from the search
        
        Returns:
          Dictionary with structure {'atoms': List[str], 'coordinates': List[np.array[float32]], 'smi': str="C"}
        """
        result_json = json.loads(result_str)
        num_conf = len(result_json["Conformers"])
        atoms = []
        coords = []
        for atom in result_json["Atoms"]:
            atoms.append(atom[0])
            coords.append(atom[3:3+3*num_conf])
        coords = np.array(coords, dtype=np.float32).flatten().reshape(len(atoms), num_conf, 3).transpose(1,0,2)
        coords /= 1000

        output = {}
        output["atoms"] = [ATOMIC_NUMBER_TO_SYMBOL[atom] for atom in atoms] # this could be changed... atoms are inherently tokened but I think we may want to differenciate H atoms
        output['coordinates'] = [conformer for conformer in coords]
        output["smi"] = "C" # random thing just in case we will ever need anything, basically a place-holder
        return output


    @lru_cache(maxsize=16)
    def __getitem__(self, idx):
        MID = self._keys[idx] # necessary because UniCore iterates over range(len(self._keys)) and not over the keys themselves
        if not hasattr(self, "hmdb"):
            self.connect_db(self.so_path, save_to_self=True)

        BufSize = 100000 # maybe need to implement dyanmic buffer sizing? could probably attatch that information to the MID?
        pBuf = (ctypes.c_char * BufSize)()
        search_result_code = self.hmdb.HugeMDB_GetMID( # <-- Assuming GetMID is correct
        MID,                 # int -> c_int
        pBuf                 # ctypes array -> POINTER(ctypes.c_char)
        )
        # print(f"\nHugeMDB_GetMID result (code): {search_result_code}")

        result_bytes = ctypes.cast(pBuf, ctypes.c_char_p).value
        try:
            result_str = result_bytes.decode('utf-8')
        except UnicodeDecodeError:
            print("Warning: Failed to decode result as UTF-8. Attempting to use 'latin-1'.")
            # Fallback to latin-1 and ignore decoding errors
            result_str = result_bytes.decode('latin-1', errors='ignore')
        # print(f"\nHugeMDB_GetMID result (code): {search_result_code}")
        
        data = self.parse_hmdb_result(result_str)
        return data