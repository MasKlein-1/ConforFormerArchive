#!/usr/bin/env python3 -u
# Copyright (c) DP Techonology, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import logging
import os
import sys
import pickle
import torch
from unicore import checkpoint_utils, distributed_utils, options, utils
from unicore.logging import progress_bar
from unicore import tasks
import time

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=os.environ.get("LOGLEVEL", "INFO").upper(),
    stream=sys.stdout,
)
logger = logging.getLogger("unimol.inference")


def main(args):
    device = "cuda"
    use_fp16 = args.fp16
    use_cuda = torch.cuda.is_available() and not args.cpu

    if use_cuda:
        torch.cuda.set_device(args.device_id)

    # Load model
    # logger.info("loading model(s) from {}".format(args.path))
    # state = checkpoint_utils.load_checkpoint_to_cpu(args.path)
    task = tasks.setup_task(args)
    model = task.build_model(args)
    # model.load_state_dict(state["model"], strict=False)

    # Move models to GPU
    if use_cuda:
        model.cuda()
        # fp16 only supported on CUDA for fused kernels
        if use_fp16:
            model.half()
    dummy_optimizer = torch.optim.Adam(params=model.parameters())
    loss = torch.nn.MSELoss()

    # Print args
    # logger.info(args)

    ### start new cript ###
    batch_sizes = [1, 2, 4, 8, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024]
    seq_lens = [8*i for i in range(5,15)]
    for size in batch_sizes:
        for seq_len in seq_lens:
            src_token = torch.randint(1, 4, size=(size, seq_len), device=device)
            src_coord = torch.randn(size=(size, seq_len, 3), device=device)
            src_distance = torch.rand(size=(size, seq_len, seq_len), device=device)
            src_edge_type = torch.randint(1, 4, size=(size, seq_len, seq_len), device=device)
            try:
                dummy1, dummy2, dummy3, dummy4, dummy5 = model(src_tokens=src_token, src_coord=src_coord, src_distance=src_distance, src_edge_type=src_edge_type)
                loss1 = loss(dummy1, torch.zeros_like(dummy1))
                loss2 = loss(dummy2, torch.zeros_like(dummy2))
                loss3 = loss(dummy3, torch.zeros_like(dummy3))
                dummy_loss = loss1 + loss2 + loss3
                dummy_loss.backward()
                dummy_optimizer.step()  # No-op
                dummy_optimizer.zero_grad()
                print(f"{size=} and {seq_len=} is fine")
            except RuntimeError as e:
                if "out of memory" in str(e):
                    print(f"{size=} and {seq_len=} is bad")
                    torch.cuda.empty_cache()  # Free up unused memory
                    break
                else:
                    raise e  # If it's a different error, raise it
    return None


def cli_main():
    parser = options.get_validation_parser()
    options.add_model_args(parser)
    args = options.parse_args_and_arch(parser)

    distributed_utils.call_main(args, main)


if __name__ == "__main__":
    cli_main()
