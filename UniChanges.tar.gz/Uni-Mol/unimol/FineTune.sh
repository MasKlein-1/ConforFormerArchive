#bin/bash

data_path=./MPP          # replace to your data path
save_dir=./save_fintune/ # replace to your save path
MASTER_PORT=10086
n_gpu=1
update_freq=8
batch_size=16
lr=1e-4

task_name="qm9dft"  # molecular property prediction task name 
dict_name="dict.txt"
task_num=3
loss_func="finetune_smooth_mae"
weight_path="Trained/checkpoint_7_990000.pt"
epoch=40

only_polar=0
conf_size=11
seed=0
dropout=0
warmup=0.06

if [ "$task_name" == "qm7dft" ] || [ "$task_name" == "qm8dft" ] || [ "$task_name" == "qm9dft" ]; then
	metric="valid_agg_mae"
elif [ "$task_name" == "esol" ] || [ "$task_name" == "freesolv" ] || [ "$task_name" == "lipo" ]; then
    metric="valid_agg_rmse"
else 
    metric="valid_agg_auc"
fi

# model architectures
num_layers=15
attn_heads=64
ffn_dropout=0.1
attn_dropout=0.1
embedding_dropout=0.1
embed_dim=512
fnn_hidden_dim=2048
g_kernel_channels=128
activation_fn=gelu

export NCCL_ASYNC_ERROR_HANDLING=1
export OMP_NUM_THREADS=1
torchrun --standalone --nnodes=1 --nproc_per_node=$n_gpu $(which unicore-train) $data_path  --user-dir ./unimol \
       --train-subset train --valid-subset valid --task-name $task_name \
       --conf-size $conf_size \
       --num-workers 8 --ddp-backend=c10d \
       --dict-name $dict_name \
       --task mol_finetune --loss $loss_func --arch unimol_base \
       --finetune-from-model $weight_path \
       --classification-head-name $task_name --num-classes $task_num \
       --optimizer adam --adam-betas "(0.9, 0.99)" --adam-eps 1e-6 --clip-norm 1.0 \
       --lr-scheduler polynomial_decay --lr $lr --warmup-ratio $warmup --max-epoch $epoch --pooler-dropout $dropout \
       --update-freq $update_freq --batch-size $batch_size --seed $seed\
       --fp16 --fp16-init-scale 4 --fp16-scale-window 256 --tensorboard-logdir $save_dir/tsb \
       --validate-interval 1 --save-interval 1 --keep-last-epochs 10\
       --log-interval 100 --log-format simple \
       --save-dir $save_dir  --only-polar $only_polar \
       --best-checkpoint-metric $metric --patience 20 \
       --keep-interval-updates 1  \
    #    --encoder-layers $num_layers --encoder-embed-dim $embed_dim --encoder-ffn-embed-dim $fnn_hidden_dim --encoder-attention-heads $attn_heads \
    #    --activation-fn $activation_fn --pooler-activation-fn $activation_fn \
    #    --emb-dropout $dropout --dropout $dropout --attention-dropout $dropout \