#bin/bash

task_name=test
results_path=dummy_batching
weight_path=./dummy_model/checkpoint_1_1.pt

# archetecture of the desired model
num_layers=16
attn_heads=64
ffn_dropout=0.1
attn_dropout=0.1
embedding_dropout=0.1
embed_dim=512
fnn_hidden_dim=2048
g_kernel_channels=128
activation_fn=gelu
mode=train
dropout=0.1


python unimol/cram_batch.py ./example_data/molecule/ --user-dir ./unimol $data_path --valid-subset test \
       --results-path $results_path \
       --num-workers 8 --ddp-backend=c10d --batch-size 1 \
       --task unimol --arch unimol_base \
       --fp16 --fp16-init-scale 4 --fp16-scale-window 256 \
       --log-interval 50 --log-format simple \
       --masked-token-loss 1 --masked-coord-loss 1 --masked-dist-loss 1 \
       --encoder-layers $num_layers --encoder-embed-dim $embed_dim --encoder-ffn-embed-dim $fnn_hidden_dim --encoder-attention-heads $attn_heads \
       --activation-fn $activation_fn --pooler-activation-fn $activation_fn \
       --emb-dropout $dropout --dropout $dropout --attention-dropout $dropout \