import lmdb
import os
import pickle
from rdkit import Chem
import pandas as pd


def main():
    path_to_data = "example_data/molecule"
    lmdb_name = "train.lmdb"
    env = lmdb.open(
        os.path.join(path_to_data, lmdb_name),
        subdir=False,
        readonly=True,
        lock=False,
        readahead=False,
        meminit=False,
        max_readers=256,
    )

    results = {
        "idx": [],
        "smi": [],
        "num_conf": [],
        "can_RD": [],
    }
    bad_smi = {
        "idx": [],
        "smi": [],
        "num_conf": [],
    }

    txn = env.begin()
    keys = list(txn.cursor().iternext(values=False))
    for idx in keys:
        dp_pikeled = txn.get(idx)
        dp = pickle.loads(dp_pikeled)

        smi = dp["smi"]
        num_conf = len(dp["coordinates"])

        can_RD = True if Chem.MolFromSmiles(smi) is not None else False
        if not can_RD:
            bad_smi["smi"].append(smi)
            bad_smi["num_conf"].append(num_conf)
            bad_smi["idx"].append(idx)
        
        results["smi"].append(smi)
        results["num_conf"].append(num_conf)
        results["can_RD"].append(can_RD)
        results["idx"].append(idx)

    temp = pd.DataFrame(results)
    temp.to_csv(os.path.join(path_to_data, "test1.csv"))
    temp = pd.DataFrame(bad_smi)
    temp.to_csv(os.path.join(path_to_data, "test2.csv"))

if __name__ == "__main__":
    main()