from multiprocessing import Pool
import os
import lmdb
import csv
import pickle

OUTPUT_DIR = "data_split"
LMDB_PATH = "example_data/molecule"

def init_lmdb_env(lmdb_path):
    env = lmdb.open(
        lmdb_path,
        subdir=False,
        readonly=True,
        lock=False,
        readahead=False,
        meminit=False,
        max_readers=256,
    )
    return env


def split_keys_n_ways(keys, n):
    output = {}
    for i in range(n):
        output[i] = []
    
    for key in keys:
        remainder = int(key)%n
        output[remainder].append(key)
    return output


def transfer_data(process_id, keys_chunk):
    env_old = init_lmdb_env(os.path.join(LMDB_PATH, "train.lmdb"))
    env_new = lmdb.open(os.path.join(OUTPUT_DIR, f"split_{process_id+1}.lmbd"), subdir=False, lock=False)

    old_db = env_old.begin()
    with env_new.begin(write=True) as new_db:
        with open(os.path.join(OUTPUT_DIR, f"split_{process_id+1}_info.csv"), mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["origional_id", "new_id", "smi", "in_split"])
            
            for idx, key in enumerate(keys_chunk):
                datapoint_pickled = old_db.get(key)
                db_idx = f"{idx}".encode("ascii")
                new_db.put(db_idx, datapoint_pickled)

                temp_data = pickle.loads(datapoint_pickled)
                smi = temp_data["smi"]
                writer.writerow([key, db_idx, smi, process_id+1])

                if idx%10000 == 0:
                    print(f"processed {idx} in process {process_id+1}")



def main(n_ways_to_split):
    env = init_lmdb_env(os.path.join(LMDB_PATH, "train.lmdb"))
    txn = env.begin()
    keys = list(txn.cursor().iternext(values=False))
    splits = split_keys_n_ways(keys, 8)
    
    tasks = [(i, chunk) for i, chunk in enumerate(splits.values())]
    with Pool(n_ways_to_split) as pool:
        results = pool.starmap(transfer_data, tasks)

if __name__ == "__main__":
    main(8)